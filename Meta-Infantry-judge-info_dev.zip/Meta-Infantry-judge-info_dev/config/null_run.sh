#!/bin/sh

# ----------------------------------------------------------------
# This script do nothing
# Set it as the executable for CLion target to enable "Run" command to perform as "Build" command
#
# Author: liuzikai
# Date: July 17 2018
# ----------------------------------------------------------------