This directory contains complex drivers subsystems. Complex Drivers must
abide to the following rules:
- Must use HAL and OSAL only.
- Cannot use RTOS functionalities.
- Cannot use HW resources directly.
- Must not use non-standard C language features.
